# A2A Adapter Mapping

A2A enables opaque agentic applications to communicate and collaborate. SemanticRouter adds DIKWP semantic routing and governance.

Mapping:
- A2A AgentCard -> SemanticRouter AgentCard
- A2A Task -> RouteRequest
- A2A Artifacts -> AgentOutput / EvidenceEntry
- A2A long-running task -> Cognitive Interaction Session

Added fields:
- dikwp_layers
- max_action_grade
- evidence_policy
- forbidden_goals
- human_review_required_when
