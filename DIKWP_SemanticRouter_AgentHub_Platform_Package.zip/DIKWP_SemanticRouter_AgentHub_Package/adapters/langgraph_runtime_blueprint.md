# LangGraph Runtime Blueprint

SemanticRouter can compile a route plan into a LangGraph-style stateful workflow.

State:
- route_request
- semantic_packet
- route_decision
- context_capsules
- agent_outputs
- evidence_ledger
- conflict_board
- action_ticket

Nodes:
- PacketizerNode
- PolicyGateNode
- CandidateDiscoveryNode
- AgentDispatchNode
- VerificationNode
- ConflictResolutionNode
- HumanApprovalNode
- FusionNode
- ReplayExportNode

Edges:
- if risk >= A3 -> HumanApprovalNode
- if evidence missing -> VerificationNode
- if conflict unresolved -> ConflictResolutionNode
- else -> FusionNode
