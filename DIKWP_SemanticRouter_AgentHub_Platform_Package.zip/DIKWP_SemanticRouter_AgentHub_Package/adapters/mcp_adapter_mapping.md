# MCP Adapter Mapping

MCP servers expose data and tools to models. SemanticRouter treats MCP tools as governed capabilities, not free actions.

Mapping:
- MCP Tool -> ToolPermission + ToolCallTicket
- MCP Tool metadata -> AgentCard.allowed_tools
- MCP Tool result -> EvidenceEntry or D-layer material
- MCP Confirmation -> ActionTicket approval

Security rules:
1. All MCP tools must be allowlisted.
2. Tool inputs must be schema-validated.
3. External content retrieved by tools is untrusted D-layer material.
4. Write operations require dry-run or human approval when risk >= A2.
