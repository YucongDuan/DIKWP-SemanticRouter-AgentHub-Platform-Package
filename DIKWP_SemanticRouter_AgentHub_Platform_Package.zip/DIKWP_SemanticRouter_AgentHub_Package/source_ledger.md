# Source Ledger

This platform package was designed by synthesizing DIKWP-style evidence-ledger and human-review patterns with current agent interoperability and orchestration references.

- YucongDuan / DIKWP-SemanticJustice-Studio-V2: https://github.com/YucongDuan/DIKWP-SemanticJustice-Studio-V2
- Model Context Protocol introduction: https://modelcontextprotocol.io/docs/getting-started/intro
- MCP tools specification: https://modelcontextprotocol.io/specification/2025-06-18/server/tools
- Agent2Agent Protocol GitHub project: https://github.com/a2aproject/A2A
- A2A documentation: https://a2a-protocol.org/
- LangGraph overview: https://docs.langchain.com/oss/python/langgraph/overview
- OWASP Top 10 for LLM Applications: https://owasp.org/www-project-top-10-for-large-language-model-applications/
- OWASP Agentic AI threats and mitigations: https://genai.owasp.org/resource/agentic-ai-threats-and-mitigations/

Design note: SemanticRouter is not a replacement for these protocols or frameworks. It is a semantic governance and routing layer above them.
