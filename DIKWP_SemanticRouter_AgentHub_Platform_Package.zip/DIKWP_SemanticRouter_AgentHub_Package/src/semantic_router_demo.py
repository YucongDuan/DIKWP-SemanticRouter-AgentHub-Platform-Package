#!/usr/bin/env python3
"""Offline DIKWP SemanticRouter demo. No model API required."""
import json, re, hashlib, datetime
from pathlib import Path
BASE = Path(__file__).resolve().parents[1]
agents = json.loads((BASE/'data/sample_agent_registry.json').read_text(encoding='utf-8'))

def risk_grade(content):
    if re.search(r'删除|支付|发送|提交|医疗|法律|金融|投资人|服务器|审计日志', content):
        return 'A3'
    return 'A1'

def packetize(req):
    content = req['content']
    layers = []
    if re.search(r'来源|核验|证据|论文|事实|引用', content): layers += ['D','K']
    if re.search(r'风险|高风险|治理|审批|医疗|法律|金融', content): layers += ['W','P']
    if re.search(r'忽略|删除|调用|服务器|安全规则', content): layers += ['P','W']
    if not layers: layers = ['I','K']
    layers = sorted(set(layers), key='DIKWP'.index)
    return {
        'packet_id': 'pkt_'+hashlib.sha1(content.encode()).hexdigest()[:8],
        'D': {'raw_content': content, 'sensitivity': req.get('sensitivity','internal')},
        'I': {'signals': [x for x in ['evidence','risk','action','injection'] if x in content.lower()]},
        'K': {'knowledge_claims': [], 'source_requirements': ['required'] if '核验' in content or '事实' in content else []},
        'W': {'risks': ['high-impact action'] if risk_grade(content) >= 'A3' else []},
        'P': {'purpose': req.get('purpose_hint','unknown'), 'forbidden_goals': ['bypass policy'] if '忽略' in content else []},
        'route': {'required_layers': layers, 'risk_grade': risk_grade(content), 'review_required': risk_grade(content) in ['A3','A4']},
        'residuals': []
    }

def score(agent, packet):
    required = set(packet['route']['required_layers'])
    layers = set(agent['dikwp_layers'])
    layer_fit = len(required & layers) / max(len(required), 1)
    trust = agent.get('trust_score', 50) / 100
    risk_ok = 1.0 if agent.get('max_action_grade','A1') >= packet['route']['risk_grade'] or packet['route']['risk_grade'] <= 'A2' else 0.3
    return round(100*(0.55*layer_fit + 0.3*trust + 0.15*risk_ok), 1)

def route(req):
    pkt = packetize(req)
    blocked = []
    if '忽略' in req['content'] and '删除' in req['content']:
        return {'request': req, 'packet': pkt, 'decision': {'selected_agents': [], 'blocked_agents': [a['agent_id'] for a in agents], 'review_required': True, 'policy_reasons': ['Prompt injection / destructive command detected'], 'action': 'KILL_AND_QUARANTINE'}}
    scored = [(a, score(a,pkt)) for a in agents]
    scored.sort(key=lambda x: x[1], reverse=True)
    selected = [a['agent_id'] for a,s in scored if s >= 55][:3]
    return {'request': req, 'packet': pkt, 'decision': {'selected_agents': selected, 'blocked_agents': blocked, 'review_required': pkt['route']['review_required'], 'score_breakdown': {a['agent_id']: s for a,s in scored}, 'policy_reasons': ['human approval required'] if pkt['route']['review_required'] else [], 'action': 'ROUTE'}}

if __name__ == '__main__':
    cases = json.loads((BASE/'data/sample_route_cases.json').read_text(encoding='utf-8'))
    bundle = {'session_id':'demo_'+datetime.datetime.utcnow().strftime('%Y%m%d%H%M%S'), 'route_log': [route(c) for c in cases]}
    out = BASE/'data/sample_route_log.json'
    out.write_text(json.dumps(bundle, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(bundle, ensure_ascii=False, indent=2))
