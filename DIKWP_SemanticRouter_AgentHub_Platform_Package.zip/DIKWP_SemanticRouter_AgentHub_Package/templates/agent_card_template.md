# Agent Capability Card

agent_id: 
name: 
owner: 
version: 
domain_tags: []
dikwp_layers: [D, I, K, W, P]
capabilities:
  - 
allowed_inputs:
  - 
outputs:
  - 
max_action_grade: A1
allowed_tools: []
forbidden_tools: []
evidence_policy: must_link_sources | optional | synthetic_only
memory_policy: no_cross_user_memory
refusal_rules:
  - clinical diagnosis
  - legal verdict
  - weaponization
trust_score: 50
latency_class: medium
cost_class: medium
human_review_required_when:
  - risk_grade >= A3
