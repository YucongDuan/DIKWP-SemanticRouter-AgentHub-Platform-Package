# Human Review Ticket

Ticket ID:
Session ID:
Route Decision ID:
Action Grade:
Risk Grade:
Proposed Action:
Why review is required:
Evidence attached:
Residuals:
Reviewer options:
- Approve
- Approve with changes
- Request more evidence
- Reject
- Escalate to domain expert
Reviewer notes:
Rollback plan:
Kill conditions:
