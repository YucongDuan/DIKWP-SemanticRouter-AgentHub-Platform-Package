# SemanticRouter Incident Report

Incident ID:
Time:
Session:
Trigger:
Affected agents:
Affected tools:
Risk grade:
What happened:
Detected by:
Immediate action:
Root cause:
Evidence:
Remediation:
Policy update required:
Owner:
Status:
